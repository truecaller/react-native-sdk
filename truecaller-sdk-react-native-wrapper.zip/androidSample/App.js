import React, { Component } from 'react';
import { Platform, StyleSheet, Text, View, Button, NativeEventEmitter,TextInput,Image,ScrollView } from 'react-native';
import Toast from 'react-native-simple-toast';
import TRUECALLER,{TRUECALLEREvent} from "react-native-truecaller"
import avatar from "./images/Avatar.png"

type Props = {};
export default class App extends Component<Props> 
{
  constructor(props) 
  {
    super(props);
    this.state = { 
       name :"",
       phone:"",
       address:"",
       email:"",
       job:"",
       company:"",
       countryCode:"",
       gender:"",
       url:avatar,
      };
      this.onButtonPress=this.onButtonPress.bind(this)
  }
  componentDidMount()
  {
    
    if(Platform.OS=="ios")
    {
       TRUECALLER.initializeClientIOS("nSEhV932f70e40e2d444998770002febb2923","https://sib6defa7d54954180b6a6d2ad8b63e40a.truecallerdevs.com")
    }
    else
    {
      TRUECALLER.initializeClient();
    }
  }
  onButtonPress()
  {
  
    TRUECALLER.on(TRUECALLEREvent.TrueProfileResponse, (profile) => 
    {
      var profiledetails=profile
     var url=profile.avatarUrl?{uri:profile.avatarUrl}:avatar
      this.setState({
        name:profile.firstName+" "+profile.lastName,
        phone:profile.phoneNumber,
        address:profile.city,
        email:profile.email,
        job:profile.jobTitle,
        company:profile.companyName,
        countryCode:profile.countryCode,
        gender:profile.gender?"Male":"Female",
        url:url
      })
    });
    TRUECALLER.on(TRUECALLEREvent.TrueProfileResponseError, (error) => 
    {
      Toast.show(error.profile,Toast.SHORT);
    });
    TRUECALLER.requestTrueProfile();



     
   

  }


  render() {
    return (
      <View style={styles.containerTop}>
        <ScrollView vertical={true} keyboardDismissMode="none" keyboardShouldPersistTaps="always" horizontal={false} pagingEnabled={true} bounces={false} scrollEnabled={true} >
          <View style={styles.container}>
            <Image style={{ height: 80, width: 80, borderRadius: 40 }} source={this.state.url} />
            <TextInput style={styles.TextInput} placeholder={"Name"} onChangeText={(name) => this.setState({ name })} value={this.state.name} />
            <TextInput style={styles.TextInput} placeholder={"Phone"} onChangeText={(phone) => this.setState({ phone })} value={this.state.phone} />
            <TextInput style={styles.TextInput} placeholder={"Address"} onChangeText={(address) => this.setState({ address })} value={this.state.address} />
            <TextInput style={styles.TextInput} placeholder={"Email"} onChangeText={(email) => this.setState({ email })} value={this.state.email} />
            <TextInput style={styles.TextInput} placeholder={"Job"} onChangeText={(job) => this.setState({ job })} value={this.state.job} />
            <TextInput style={styles.TextInput} placeholder={"Company"} onChangeText={(company) => this.setState({ company })} value={this.state.company} />
            <TextInput style={styles.TextInput} placeholder={"Gender"} onChangeText={(gender) => this.setState({ gender })} value={this.state.gender} />
            <Button style={styles.buttonStyle} title='Auto fill with TrueCaller Profile' onPress={this.onButtonPress} />
          </View>
        </ScrollView>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  TextInput:
  {
    height: 40,
    width:275,

  },
  buttonStyle:
  {
    height: 100,
    width:40,
  },
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#F5FCFF',
    
  },
  containerTop: {
    flex: 1,
    top:50,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#F5FCFF',
    
  },
  welcome: {
    fontSize: 20,
    textAlign: 'center',
    margin: 10,
  },
  instructions: {
    textAlign: 'center',
    color: '#333333',
    marginBottom: 5,
  },
});
