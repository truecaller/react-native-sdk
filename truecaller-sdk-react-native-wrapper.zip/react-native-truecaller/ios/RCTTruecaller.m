#import "RCTTruecaller.h"
#import <React/RCTLog.h>

#import <React/RCTBridge.h>
#import <React/RCTEventDispatcher.h>
#import <React/RCTLog.h>
#import <React/RCTUtils.h>


@implementation RCTTruecaller

RCT_EXPORT_MODULE();


RCT_EXPORT_METHOD(initializeClientIOS:(NSString *)appKey appLink:(NSString *)appLink)
{
  NSLog(@"initializeClient");
  if ([[TCTrueSDK sharedManager] isSupported])
  {
    [TCTrueSDK sharedManager].delegate = self;
    [[TCTrueSDK sharedManager] setupWithAppKey:appKey appLink:appLink];
    _appLink=appLink;
    _appKey=appKey;
  }
  else
  {



    [self sendEventWithName:@"didReceiveTrueProfileResponseError" body:@{@"profile":@"Error, SDK not Supported"}];
    return;
  }

}

- (NSArray<NSString *> *)supportedEvents
{
  return @[@"didReceiveTrueProfileResponse",@"didReceiveTrueProfileResponseError"];
}


RCT_EXPORT_METHOD(requestTrueProfile)
{



  if (![TCUtils isOperatingSystemSupported])
  {

    [self sendEventWithName:@"didReceiveTrueProfileResponseError" body:@{@"profile":@"Error, IOS not Supported"}];
    return;
  }

  if (![TCUtils isTruecallerInstalled])
  {

    [self sendEventWithName:@"didReceiveTrueProfileResponseError" body:@{@"profile":@"Error, Truecaller is Not Installed"}];
    return;
  }

  if (_appKey == nil || _appKey.length == 0)
  {
    [self sendEventWithName:@"didReceiveTrueProfileResponseError" body:@{@"profile":@"Error, appKey should not empty "}];
    return;
  }

  if (_appLink == nil || _appLink.length == 0)
  {
    [self sendEventWithName:@"didReceiveTrueProfileResponseError" body:@{@"profile":@"Error, appLink should not empty "}];
    return;
  }
  if ([[TCTrueSDK sharedManager] isSupported])
  {
    [[TCTrueSDK sharedManager] setupWithAppKey:_appKey appLink:_appLink];
  }

  [TCTrueSDK sharedManager].delegate = self;
  TCTrueProfileRequest *profileRequest = [TCTrueProfileRequest new];
  profileRequest.appKey = _appKey;
  profileRequest.appLink = _appLink;
  profileRequest.appId = [[NSBundle mainBundle] bundleIdentifier];
  profileRequest.apiVersion = [TCUtils getAPIVersion];
  profileRequest.sdkVersion = [TCUtils getSDKVersion];
  profileRequest.appName = [[NSBundle mainBundle] objectForInfoDictionaryKey:@"CFBundleName"];
  NSString *requestNonce = [NSUUID UUID].UUIDString;
  profileRequest.requestNonce = requestNonce;
  NSURLComponents *urlComponents = [NSURLComponents componentsWithString:@"https://www.truecaller.com/userProfile"];
  NSData *itemData = [NSKeyedArchiver archivedDataWithRootObject:profileRequest];
  NSString *itemString = [itemData base64EncodedStringWithOptions:NSDataBase64Encoding64CharacterLineLength];
  NSURLQueryItem *queryItem = [NSURLQueryItem queryItemWithName:kTrueProfileRequestKey value:itemString];
  urlComponents.queryItems = @[queryItem];
  NSURL *url = urlComponents.URL;
  [TCUtils openUrl:url completionHandler:nil];
  NSLog(@"requestTrueProfile ");
};

- (void)willRequestProfileWithNonce:(nonnull NSString *)nonce;
{
  NSLog(@" nonce %@", nonce);
}

/*!
 * @brief Use this optional delegate method to get the whole response instance and implement additional security checks
 * @param profileResponse The profile response which contains the payload, signature and nonce
 */
- (void)didReceiveTrueProfileResponse:(nonnull TCTrueProfileResponse *)profileResponse;
{
  NSLog(@" profileResponse %@", profileResponse.payload);
}

- (void)didReceiveTrueProfile:(nonnull TCTrueProfile *)profile
{



  NSMutableDictionary *profileDetails=[[NSMutableDictionary alloc]init];


  [profileDetails setValue:profile.firstName forKey:@"firstName"];
  [profileDetails setValue:profile.lastName forKey:@"lastName"];
  [profileDetails setValue:profile.phoneNumber forKey:@"phoneNumber"];
  [profileDetails setValue:[NSNumber numberWithBool:profile.gender] forKey:@"gender"];
  [profileDetails setValue:profile.street forKey:@"street"];
  [profileDetails setValue:profile.city forKey:@"city"];
  [profileDetails setValue:profile.zipCode forKey:@"zipcode"];
  [profileDetails setValue:profile.countryCode forKey:@"countryCode"];
  [profileDetails setValue:profile.facebookID forKey:@"facebookId"];
  [profileDetails setValue:profile.twitterID forKey:@"twitterId"];
  [profileDetails setValue:profile.email forKey:@"email"];
  [profileDetails setValue:profile.avatarURL forKey:@"avatarUrl"];
  [profileDetails setValue:[NSNumber numberWithBool:profile.isVerified] forKey:@"isTrueName"];
  [profileDetails setValue:[NSNumber numberWithBool:profile.isAmbassador] forKey:@"isAmbassador"];
  [profileDetails setValue:profile.companyName forKey:@"companyName"];
  [profileDetails setValue:profile.jobTitle forKey:@"jobTitle"];
  [profileDetails setValue:@"" forKey:@"payload"];
  [profileDetails setValue:@"" forKey:@"signature"];
  [profileDetails setValue:@"" forKey:@"signatureAlgorithm"];
  [profileDetails setValue:@"" forKey:@"requestNonce"];


  [self sendEventWithName:@"didReceiveTrueProfileResponse" body:profileDetails];
}
- (void)didFailToReceiveTrueProfileWithError:(nonnull TCError *)error
{

  [self sendEventWithName:@"didReceiveTrueProfileResponseError" body:@{@"profile":@"Error, Please try with right config"}];

}
@end




